import { test, expect } from '@playwright/test';

test.describe('End Trip Flow', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/login');
    await page.fill('input[type="tel"]', '081234567890');
    await page.fill('input[type="password"]', '123456');
    await page.click('button:has-text("Masuk")');
    await page.waitForURL('**/go');
  });

  test('should show end trip dashboard', async ({ page }) => {
    await expect(page.locator('text=Ringkasan Eco-Driving')).toBeVisible();
  });

  test('should display eco score', async ({ page }) => {
    await expect(page.locator('text=ECO SCORE')).toBeVisible();
    const score = page.locator('text=/^\\d+\\/100$/');
    await expect(score).toBeVisible();
  });

  test('should display trip duration', async ({ page }) => {
    await expect(page.locator('text=TRIP')).toBeVisible();
  });

  test('should display trip distance', async ({ page }) => {
    await expect(page.locator('text=km')).toBeVisible();
  });

  test('should display BrigaCoins earned', async ({ page }) => {
    await expect(page.locator('text=BrigaCoins')).toBeVisible();
  });

  test('should display token breakdown', async ({ page }) => {
    await expect(page.locator('text=Base Reward')).toBeVisible();
    await expect(page.locator('text=Multiplier Eco Score')).toBeVisible();
  });

  test('should display verification status', async ({ page }) => {
    await expect(page.locator('text=VERIFIED, REJECTED, or PENDING')).toBeVisible();
  });

  test('should display trip hash', async ({ page }) => {
    await expect(page.locator('text=SHA-256 Hash')).toBeVisible();
  });

  test('should copy trip hash', async ({ page }) => {
    await page.click('button[title="Salin Hash"]');
    await expect(page.locator('text=Hash copied')).toBeVisible();
  });

  test('should navigate to new trip', async ({ page }) => {
    await page.click('button:has-text("Trip Baru")');
    await page.waitForURL('**/login');
  });

  test('should show sensor diagnostics', async ({ page }) => {
    await expect(page.locator('text=SENSOR DIAGNOSTIK')).toBeVisible();
  });

  test('should show harsh acceleration count', async ({ page }) => {
    await expect(page.locator('text=Harsh Accel')).toBeVisible();
  });

  test('should show harsh brake count', async ({ page }) => {
    await expect(page.locator('text=Harsh Brake')).toBeVisible();
  });

  test('should show max speed', async ({ page }) => {
    await expect(page.locator('text=max:')).toBeVisible();
  });

  test('should show CO2 avoided', async ({ page }) => {
    await expect(page.locator('text=CO₂ Dihindari')).toBeVisible();
  });

  test('should show efficiency', async ({ page }) => {
    await expect(page.locator('text=kWh/100km')).toBeVisible();
  });

  test('should show eco grade', async ({ page }) => {
    await expect(page.locator('text=Grade:')).toBeVisible();
  });

  test('should show profile used', async ({ page }) => {
    await expect(page.locator('text=Profil:')).toBeVisible();
  });

  test('should show start and end SoC', async ({ page }) => {
    await expect(page.locator('text=Awal:')).toBeVisible();
    await expect(page.locator('text=Akhir:')).toBeVisible();
  });

  test('should show start and end odometer', async ({ page }) => {
    await expect(page.locator('text=Awal:')).toBeVisible();
    await expect(page.locator('text=Akhir:')).toBeVisible();
  });

  test('should show energy consumption', async ({ page }) => {
    await expect(page.locator('text=Konsumsi:')).toBeVisible();
  });

  test('should show average speed', async ({ page }) => {
    await expect(page.locator('text=Rata-rata:')).toBeVisible();
  });

  test('should show idle duration', async ({ page }) => {
    await expect(page.locator('text=Idle')).toBeVisible();
  });

  test('should show GPS gaps', async ({ page }) => {
    await expect(page.locator('text=GPS Gaps')).toBeVisible();
  });

  test('should show streak bonus if applicable', async ({ page }) => {
    const streakBonus = page.locator('text=Streak Bonus');
    if (await streakBonus.isVisible()) {
      await expect(streakBonus).toBeVisible();
    }
  });

  test('should show clean driving bonus if applicable', async ({ page }) => {
    const cleanBonus = page.locator('text=Clean Bonus');
    if (await cleanBonus.isVisible()) {
      await expect(cleanBonus).toBeVisible();
    }
  });

  test('should show rush hour badge if applicable', async ({ page }) => {
    const rushHour = page.locator('text=RUSH HOUR');
    if (await rushHour.isVisible()) {
      await expect(rushHour).toBeVisible();
    }
  });

  test('should show auto-purge message if verified', async ({ page }) => {
    const purgeMsg = page.locator('text=Auto-Purge');
    if (await purgeMsg.isVisible()) {
      await expect(purgeMsg).toBeVisible();
    }
  });

  test('should show rejection message if rejected', async ({ page }) => {
    const rejectMsg = page.locator('text=Trip Rejected');
    if (await rejectMsg.isVisible()) {
      await expect(rejectMsg).toBeVisible();
    }
  });
});
